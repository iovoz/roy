Interfaces.ContentScriptDialogInterface=function(){var e,n;return{LPDialog:{openDialog:new Interfaces.Definition(Interfaces.TYPE_FUNCTION)}}}();
//# sourceMappingURL=sourcemaps/contentScriptDialogInterface.js.map
