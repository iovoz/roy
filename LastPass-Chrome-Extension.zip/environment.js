var Environment={version:"4.41.0.3",environment:"prod",lastpass_url:"https://lastpass.com/"};
//# sourceMappingURL=sourcemaps/environment.js.map
