Interfaces.ExtensionLoginDropdownInterface=function(){var n=Interfaces.Definition,e=Interfaces.TYPE_FUNCTION;return{LPPlatform:{onLoad:new n(e)},ExtensionDropdown:{open:new n(e),reset:new n(e)}}}();
//# sourceMappingURL=sourcemaps/extensionLoginDropdownInterface.js.map
