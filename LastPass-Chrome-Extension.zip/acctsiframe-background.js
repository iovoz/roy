!function(t){var o={};t.onSettingsIframeClose=function(t,n){n?o[n.tabID]=t:o=t},t.closeSettingsIframe=function(t,n){n&&"function"==typeof o[n.tabID]?o[n.tabID]():"function"==typeof o&&o()}}(this);
//# sourceMappingURL=sourcemaps/acctsiframe-background.js.map
