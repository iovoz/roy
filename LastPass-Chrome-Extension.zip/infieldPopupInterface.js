Interfaces.InfieldPopupInterface=function(){var e,n;return{lpInfield:{setArrowPosition:new Interfaces.Definition(Interfaces.TYPE_FUNCTION,{include:["contentScript"]})}}}();
//# sourceMappingURL=sourcemaps/infieldPopupInterface.js.map
