$=jQuery=window.jQuery;
//# sourceMappingURL=sourcemaps/firefox_jquery_cs_fix.js.map
