sr(document,"generatebutton","value","Generate"),sr(document,"generatesave","value",getBG().can_copy_to_clipboard()?"Copy":"Save"),sr(document,"generateclose","value","Close");
//# sourceMappingURL=sourcemaps/lp_toolstrip18.js.map
