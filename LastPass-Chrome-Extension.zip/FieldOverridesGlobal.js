var FieldOverridesGlobal=function(){var e="off",r="username",o="new-password",u="current-password",n={"auth.onefluor.com/eai/fluorauth/login":{querySelector:"#password",override:e},"herouw.com":{querySelector:'input[name="dummypass"]',override:e}};function t(){return n}function a(e){return n[e]}return{getAll:t,getSite:a}}();
//# sourceMappingURL=sourcemaps/FieldOverridesGlobal.js.map
