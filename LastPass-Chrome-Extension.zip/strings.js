StringUtils={},function(t){t.translate=function(t){if(t){var r=t.trim();if(0<r.length){var n=LPPlatform.translate(r);if(1<arguments.length)for(var e=1,i=arguments.length;e<i;++e){var a=arguments[e];"object"!=typeof a&&(n=n.replace("%"+e,a.toString()))}return n}}return t}}(StringUtils);
//# sourceMappingURL=sourcemaps/strings.js.map
