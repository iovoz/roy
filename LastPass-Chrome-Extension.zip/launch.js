dispatch_message("launch",{aid:getQueryVariable("aid")});
//# sourceMappingURL=sourcemaps/launch.js.map
