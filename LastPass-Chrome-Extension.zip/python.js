var False=!1,True=!0,pass=!0;
//# sourceMappingURL=sourcemaps/python.js.map
