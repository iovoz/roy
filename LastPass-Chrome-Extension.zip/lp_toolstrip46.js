document.getElementById("sesameauth")&&set_innertext(document.getElementById("sesameauth"),gs("Authenticate"));
//# sourceMappingURL=sourcemaps/lp_toolstrip46.js.map
