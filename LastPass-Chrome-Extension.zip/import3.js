document.getElementById("selectall").value=gs("Select All"),document.getElementById("unselectall").value=gs("Unselect All"),set_innertext(document.getElementById("lpimport"),gs("Import")),document.getElementById("cancel").value=gs("Cancel");
//# sourceMappingURL=sourcemaps/import3.js.map
